import { Link } from "react-router-dom";

const cards = [
  { path: "/aktualnosci", icon: "📰", title: "Aktualności" },
  { path: "/brd", icon: "🚗", title: "Bezpieczeństwo Ruchu Drogowego" },
  { path: "/egzaminy", icon: "📝", title: "Egzaminy" },
  { path: "/dokumenty", icon: "📄", title: "Dokumenty do pobrania, wnioski" },
  { path: "/kontakt", icon: "📬", title: "Kontakt" },
  { path: "/dzierzawa", icon: "⚙️", title: "Dzierżawa stanowisk egzaminacyjnych" },
];

export default function Index() {
  return (
    <div className="dord-grid">
      {cards.map((card) => (
        <Link key={card.path} to={card.path} className="dord-card">
          <div className="dord-icon-box">{card.icon}</div>
          <h3>{card.title}</h3>
          <div className="dord-link-text">Przejdź do podstrony ›</div>
        </Link>
      ))}
    </div>
  );
}
