export default function Dzierzawa() {
  return (
    <div className="dord-subpage">
      <h1>⚙️ Dzierżawa stanowisk egzaminacyjnych</h1>
      <p>DORD oferuje możliwość dzierżawy stanowisk egzaminacyjnych dla ośrodków szkolenia kierowców.</p>

      <h2>Warunki dzierżawy</h2>
      <ul>
        <li>Dostępność placu manewrowego w godzinach popołudniowych i weekendowych</li>
        <li>Możliwość dzierżawy pojedynczych stanowisk lub całego placu</li>
        <li>Umowa dzierżawy na okres minimum 1 miesiąca</li>
        <li>Możliwość negocjacji warunków dla stałych klientów</li>
      </ul>

      <h2>Kontakt w sprawie dzierżawy</h2>
      <p>W celu uzyskania szczegółowych informacji prosimy o kontakt z Referatem Obsługi Klienta:</p>
      <p><strong>Telefon:</strong> 605 390 446<br /><strong>Email:</strong> boleslawiec@dord.dolnyslask.pl</p>
    </div>
  );
}
