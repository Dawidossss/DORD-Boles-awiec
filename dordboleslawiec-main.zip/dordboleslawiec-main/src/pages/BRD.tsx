export default function BRD() {
  return (
    <div className="dord-subpage">
      <h1>🚗 Bezpieczeństwo Ruchu Drogowego</h1>
      <p>DORD prowadzi działalność edukacyjną i szkoleniową w zakresie bezpieczeństwa ruchu drogowego.</p>

      <h2>Nasze działania</h2>
      <ul>
        <li>Organizacja szkoleń i warsztatów BRD dla dzieci i młodzieży</li>
        <li>Współpraca ze szkołami i instytucjami w zakresie edukacji drogowej</li>
        <li>Przeprowadzanie egzaminów z zakresu BRD</li>
        <li>Opracowywanie materiałów edukacyjnych</li>
      </ul>

      <h2>Materiały do pobrania</h2>
      <p>Zaktualizowane materiały szkoleniowe są dostępne w zakładce <strong>Dokumenty do pobrania</strong>.</p>
    </div>
  );
}
