export default function Dokumenty() {
  return (
    <div className="dord-subpage">
      <h1>📄 Dokumenty do pobrania</h1>
      <p>Poniżej znajdziesz wnioski i dokumenty potrzebne do załatwienia spraw w DORD.</p>

      <div className="dord-doc-list">
        {[
          "Wniosek o wyznaczenie terminu egzaminu",
          "Wniosek o wydanie prawa jazdy",
          "Formularz reklamacji",
          "Regulamin egzaminów państwowych",
          "Cennik opłat egzaminacyjnych",
          "Materiały szkoleniowe BRD",
        ].map((doc, i) => (
          <div key={i} className="dord-doc-item">
            <span>📎</span>
            <span>{doc}</span>
            <button className="dord-doc-btn">Pobierz PDF</button>
          </div>
        ))}
      </div>
    </div>
  );
}
