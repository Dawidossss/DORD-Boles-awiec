export default function Kontakt() {
  return (
    <div className="dord-subpage">
      <h1>📬 Kontakt</h1>

      <div className="dord-contact-grid">
        <div className="dord-contact-card">
          <h3>Oddział Bolesławiec</h3>
          <p>ul. Lubańska 75<br />59-700 Bolesławiec</p>
          <p><strong>Telefon:</strong> 605 390 446</p>
          <p><strong>Email:</strong> boleslawiec@dord.dolnyslask.pl</p>
          <p><strong>Godziny pracy:</strong><br />Poniedziałek – Piątek: 8:00 – 14:30</p>
        </div>

        <div className="dord-contact-card">
          <h3>Siedziba główna DORD</h3>
          <p>ul. Łączna 1<br />50-104 Wrocław</p>
          <p><strong>Telefon:</strong> 71 328 22 00</p>
          <p><strong>Email:</strong> sekretariat@dord.dolnyslask.pl</p>
          <p><strong>Godziny pracy:</strong><br />Poniedziałek – Piątek: 7:30 – 15:30</p>
        </div>
      </div>
    </div>
  );
}
