export default function Egzaminy() {
  return (
    <div className="dord-subpage">
      <h1>📝 Egzaminy</h1>
      <p>Dolnośląski Ośrodek Ruchu Drogowego przeprowadza egzaminy państwowe na prawo jazdy wszystkich kategorii.</p>

      <h2>Kategorie egzaminów</h2>
      <div className="dord-exam-grid">
        {[
          { cat: "AM", desc: "Motorower" },
          { cat: "A1", desc: "Motocykl do 125cm³" },
          { cat: "A2", desc: "Motocykl do 35kW" },
          { cat: "A", desc: "Motocykl" },
          { cat: "B1", desc: "Czterokołowiec" },
          { cat: "B", desc: "Samochód osobowy" },
          { cat: "C", desc: "Samochód ciężarowy" },
          { cat: "D", desc: "Autobus" },
        ].map((e) => (
          <div key={e.cat} className="dord-exam-item">
            <span className="dord-exam-cat">{e.cat}</span>
            <span>{e.desc}</span>
          </div>
        ))}
      </div>

      <h2>Jak się zapisać?</h2>
      <ol>
        <li>Skompletuj wymagane dokumenty</li>
        <li>Złóż wniosek w Referacie Obsługi Klienta</li>
        <li>Opłać egzamin</li>
        <li>Otrzymaj wyznaczony termin egzaminu</li>
      </ol>
    </div>
  );
}
