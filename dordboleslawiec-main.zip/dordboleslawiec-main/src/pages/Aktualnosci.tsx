export default function Aktualnosci() {
  return (
    <div className="dord-subpage">
      <h1>📰 Aktualności</h1>
      <div className="dord-news-item">
        <span className="dord-news-date">15.03.2026</span>
        <h3>DORD Bolesławiec już niedługo otwarty!</h3>
        <p>Z radością informujemy, że oddział w Bolesławcu zostanie otwarty w najbliższych tygodniach. Zapraszamy do śledzenia naszej strony po więcej informacji.</p>
      </div>
      <div className="dord-news-item">
        <span className="dord-news-date">10.03.2026</span>
        <h3>Poszukujemy pracowników na stanowisko Egzaminatora</h3>
        <p>Dolnośląski Ośrodek Ruchu Drogowego prowadzi rekrutację na stanowisko egzaminatora. Szczegóły oferty dostępne w zakładce Kontakt.</p>
      </div>
      <div className="dord-news-item">
        <span className="dord-news-date">01.03.2026</span>
        <h3>Nowe materiały szkoleniowe BRD</h3>
        <p>Udostępniliśmy zaktualizowane materiały szkoleniowe z zakresu bezpieczeństwa ruchu drogowego. Można je pobrać w zakładce Dokumenty.</p>
      </div>
    </div>
  );
}
