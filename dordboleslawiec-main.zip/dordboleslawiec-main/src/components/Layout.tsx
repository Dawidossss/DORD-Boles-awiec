import { Link, Outlet, useLocation } from "react-router-dom";

const navItems = [
  { path: "/", label: "Strona główna", icon: "🏠" },
  { path: "/aktualnosci", label: "Aktualności", icon: "📰" },
  { path: "/brd", label: "Bezpieczeństwo Ruchu Drogowego", icon: "🚗" },
  { path: "/egzaminy", label: "Egzaminy", icon: "📝" },
  { path: "/dokumenty", label: "Dokumenty", icon: "📄" },
  { path: "/kontakt", label: "Kontakt", icon: "📬" },
  { path: "/dzierzawa", label: "Dzierżawa stanowisk", icon: "⚙️" },
];

const tickerItems = [
  "DORD Bolesławiec już niedługo otwarty!",
  "Puszukujemy pracowników na stanowisko Egzaminatora",
  "Strona zrobiona przez Herr Tusk",
  "W sprawie pytań zapraszamy do kontaktu!",
];

export default function Layout() {
  const location = useLocation();

  return (
    <div className="dord-root">
      {/* HEADER */}
      <header className="dord-header">
        <Link to="/" className="dord-logo-area">
          <div className="dord-logo-dots">
            {Array.from({ length: 9 }).map((_, i) => (
              <span key={i} />
            ))}
          </div>
          <span className="dord-logo-text">dord</span>
        </Link>
        <span className="dord-header-title">Dolnośląski Ośrodek Ruchu Drogowego</span>
      </header>

      {/* TICKER */}
      <div className="dord-ticker-bar">
        <span className="dord-ticker-badge">📢 Nowości</span>
        <div className="dord-ticker-wrap">
          <div className="dord-ticker">
            {[...tickerItems, ...tickerItems].map((t, i) => (
              <span key={i}>{t}</span>
            ))}
          </div>
        </div>
      </div>

      {/* NAV */}
      <nav className="dord-nav">
        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`dord-nav-link ${location.pathname === item.path ? "active" : ""}`}
          >
            <span className="dord-nav-icon">{item.icon}</span>
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>

      {/* CONTENT */}
      <div className="dord-page">
        <aside className="dord-sidebar">
          <h2>Bolesławiec</h2>
          <hr />
          <div className="dord-address">
            <span>📍</span>
            <span>ul. Lubańska 75, 59-700<br />Bolesławiec</span>
          </div>
          <p className="dord-section-title">Referat Obsługi Klienta</p>
          <div className="dord-info-line">📞 605 390 446</div>
          <div className="dord-info-line">✉️ boleslawiec@dord.dolnyslask.pl</div>
          <div className="dord-info-line">🕐 PN-PT 8:00 - 14:30</div>
        </aside>

        <main className="dord-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
