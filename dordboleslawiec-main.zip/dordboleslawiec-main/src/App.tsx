import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Layout from "./components/Layout";
import Index from "./pages/Index";
import Aktualnosci from "./pages/Aktualnosci";
import BRD from "./pages/BRD";
import Egzaminy from "./pages/Egzaminy";
import Dokumenty from "./pages/Dokumenty";
import Kontakt from "./pages/Kontakt";
import Dzierzawa from "./pages/Dzierzawa";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Index />} />
            <Route path="/aktualnosci" element={<Aktualnosci />} />
            <Route path="/brd" element={<BRD />} />
            <Route path="/egzaminy" element={<Egzaminy />} />
            <Route path="/dokumenty" element={<Dokumenty />} />
            <Route path="/kontakt" element={<Kontakt />} />
            <Route path="/dzierzawa" element={<Dzierzawa />} />
          </Route>
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
